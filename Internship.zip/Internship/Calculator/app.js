function toDisplay(value) {
    document.getElementById('display').value += value;
}

function clearDisplay() {
    document.getElementById('display').value = "";
}

function calculate() {
    let expr = document.getElementById('display').value;
    try {
        let result = eval(expr);
        if (isNaN(result) || !isFinite(result)) {
            document.getElementById('display').value = "Error";
        } else {
            document.getElementById('display').value = result;
        }
    } catch (error) {
        document.getElementById('display').value = "Error";
    }
}
