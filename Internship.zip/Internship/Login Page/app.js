document.addEventListener("DOMContentLoaded", function () {
    const loginLink = document.querySelector("a[href='#']");
    const passwordInput = document.querySelector('input[name="password"]');
    const passwordIcon = document.querySelector("#password-toggle");
    const usernameInput = document.querySelector('input[name="username"]'); 
    loginLink.addEventListener("click", function (event) {
        event.preventDefault();
        const username = usernameInput.value;
        const password = passwordInput.value;

        if (username === "" || password === "") {
            alert("Both username and password are required.");
        } else {
            if (username === "Rupesh2004" && password === "Rupesh@2004") {
                alert("Login successful!");
                usernameInput.value = "";
                passwordInput.value = "";
            }
            else {
                alert("Invalid Credentials");
            }
        }
    });
    passwordIcon.addEventListener("click", function () {
        if (passwordInput.type === "password") {
            passwordInput.type = "text";
        } else {
            passwordInput.type = "password";
        }
    });
});